export default function DashboardPage() {
  return (
    <div style={{ padding: "2rem", textAlign: "center" }}>
      <h1>Welcome to Your Dashboard</h1>
      <p>You are now securely logged in. ✅</p>
    </div>
  );
}
